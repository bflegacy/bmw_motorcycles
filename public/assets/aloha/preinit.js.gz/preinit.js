window.Aloha.settings.baseUrl = '/assets/aloha/lib/';
