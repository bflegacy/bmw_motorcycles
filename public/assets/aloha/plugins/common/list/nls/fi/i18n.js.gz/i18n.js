define({"button.createulist.tooltip":"Lis\u00e4\u00e4 j\u00e4rjestelem\u00e4t\u00f6n lista","button.createolist.tooltip":"Lis\u00e4\u00e4 j\u00e4rjestelty lista"});
