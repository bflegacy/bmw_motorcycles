define({"button.addcharacter.tooltip": "Sonderzeichen einf&uuml;gen"});
