define({"button.addhr.tooltip": "Eine horizontale Linie hinzuf&uuml;gen"});
