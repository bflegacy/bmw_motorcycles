define({ 'button.addimg.tooltip': 'insérer média' });
