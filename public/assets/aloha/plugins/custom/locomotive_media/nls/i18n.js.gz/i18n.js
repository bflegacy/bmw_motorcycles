define({
  root: { "button.addimg.tooltip": "insert media" },
  fr: true
});
