define({ "headerids.label.target": "Target", "headerids.button.reset":"Reset","headerids.button.set":"Set" });
