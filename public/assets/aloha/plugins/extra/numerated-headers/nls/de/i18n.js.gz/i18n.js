define( { "button.numeratedHeaders.tooltip": "Ueberschriftennummerierung ein- bzw. ausschalten." });
