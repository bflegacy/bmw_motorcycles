define({ "headerids.label.target": "Sprungziel", "headerids.button.reset":"Zur&uuml;cksetzen","headerids.button.set":"Zuweisen" });
