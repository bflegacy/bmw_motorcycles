define( {
	'floatingmenu.tab.format': 'Formatieren',
	'floatingmenu.tab.insert': 'Einf\u00fcgen',
	'yes': 'Ja',
	'no': 'Nein',
	'cancel': 'Abbrechen',
	'repository.no_item_found': 'Keinen Eintrag gefunden.',
	'repository.loading': 'Es wird geladen',
	'repository.no_items_found_yet': 'Noch keine Eintr\u00e4ge gefunden...'
} );
